# This file is a file used in Exercise02 of Lab01.

print('Hello World!')
